
#include "stdafx.h"
#include <stdio.h>
#include <windows.h>
#include <tchar.h>
#include <tlhelp32.h>
#include <direct.h>
#include <stdlib.h>

#include <Shlwapi.h>
#pragma comment(lib, "shlwapi")
#pragma comment(lib,"Advapi32.lib") 

#include "a.h"
typedef long NTSTATUS;
typedef NTSTATUS(NTAPI* pfnNtCreateThreadEx)
(
	OUT PHANDLE hThread,
	IN ACCESS_MASK DesiredAccess,
	IN PVOID ObjectAttributes,
	IN HANDLE ProcessHandle,
	IN PVOID lpStartAddress,
	IN PVOID lpParameter,
	IN ULONG Flags,
	IN SIZE_T StackZeroBits,
	IN SIZE_T SizeOfStackCommit,
	IN SIZE_T SizeOfStackReserve,
	OUT PVOID lpBytesBuffer);



//����ǰ������ 
RISKAPIPROXY_API BOOL   CreateRemoteThreadLoadDll(LPCWSTR   lpwLibFile, DWORD64   dwProcessId);
RISKAPIPROXY_API BOOL   CreateRemoteThreadUnloadDll(LPCWSTR   lpwLibFile, DWORD64   dwProcessId);
RISKAPIPROXY_API HANDLE MyCreateRemoteThread(HANDLE hProcess, LPTHREAD_START_ROUTINE pThreadProc, LPVOID pRemoteBuf);
RISKAPIPROXY_API BOOL CheckIsInject(DWORD dwProcessid);

BOOL FreeDll(UINT32 ProcessId, LPCWSTR DllFullPath);
BOOL   EnableDebugPrivilege();


//************************************************************
// ��������: CheckIsInject
// ����˵��: ����Ƿ��Ѿ�ע��dll
// ��    ��: GuiShou
// ʱ    ��: 2019/6/30
// ��    ��: void
// �� �� ֵ: BOOL 
//************************************************************
BOOL CheckIsInject(DWORD dwProcessid)
{
	HANDLE hModuleSnap = INVALID_HANDLE_VALUE;
	//��ʼ��ģ����Ϣ�ṹ��
	MODULEENTRY32 me32 = { sizeof(MODULEENTRY32) };
	//����ģ����� 1 �������� 2 ����ID
	hModuleSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwProcessid);
	//��������Ч�ͷ���false
	if (hModuleSnap == INVALID_HANDLE_VALUE)
	{
		MessageBoxA(NULL, "����ģ�����ʧ��", "����", MB_OK);
		return FALSE;
	}
	//ͨ��ģ����վ����ȡ��һ��ģ�����Ϣ
	if (!Module32First(hModuleSnap, &me32))
	{
		MessageBoxA(NULL, "��ȡ��һ��ģ�����Ϣʧ��", "����", MB_OK);
		//��ȡʧ����رվ��
		CloseHandle(hModuleSnap);
		return FALSE;
	}
	do
	{
			if (StrCmpW(me32.szModule, L"WxInterface.dll") == 0)
		{
			return FALSE;
		}

	} while (Module32Next(hModuleSnap, &me32));
	return TRUE;
}


BOOL   CreateRemoteThreadLoadDll(LPCWSTR   lpwLibFile, DWORD64   dwProcessId)
{
	BOOL   bRet = FALSE;
	HANDLE   hProcess = NULL, hThread = NULL;
	LPVOID pszLibRemoteFile = NULL;
	SIZE_T dwWritten = 0;
	__try
	{

		if (EnableDebugPrivilege) {
			hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
			if (hProcess == NULL)__leave;
			
			int   cch = 1 + lstrlenW(lpwLibFile);			
			int   cb = cch * sizeof(WCHAR);
			
			pszLibRemoteFile = VirtualAllocEx(hProcess, NULL, cb, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
			if (pszLibRemoteFile == NULL)
				__leave;
			BOOL   bw = WriteProcessMemory(hProcess, pszLibRemoteFile, (PVOID)lpwLibFile, cb, &dwWritten);
			if (dwWritten != cb)
			{
				//	printf("write error!\n");
			}
			if (!bw)
				__leave;

			
			HMODULE Kernel32Module = GetModuleHandle(L"Kernel32");
			LPTHREAD_START_ROUTINE	LoadLibraryAddress = (LPTHREAD_START_ROUTINE)GetProcAddress(Kernel32Module, "LoadLibraryA");
			
			hThread = MyCreateRemoteThread(hProcess, LoadLibraryAddress, pszLibRemoteFile);
		
			if (hThread == NULL)
				__leave;
			WaitForSingleObject(hThread, INFINITE);
     		bRet = TRUE;
		}
		else
			bRet = FALSE;
	}
	__finally
	{
		if (pszLibRemoteFile != NULL)
			if (VirtualFreeEx(hProcess, pszLibRemoteFile, 0, MEM_RELEASE) ){
			}

		if (hThread != NULL)
			CloseHandle(hThread);

		if (hProcess != NULL)
			CloseHandle(hProcess);
	}

	return   bRet;
}
//--------------------------------------------------------------------- 


BOOL FreeDll(UINT32 ProcessId, LPCWSTR DllFullPath)
{
	BOOL bMore = FALSE, bFound = FALSE;
	HANDLE hSnapshot;
	HMODULE hModule = NULL;
	MODULEENTRY32 me = { sizeof(me) };
	BOOL bSuccess = FALSE;
	hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, ProcessId);
	bMore = Module32First(hSnapshot, &me);
	for (; bMore; bMore = Module32Next(hSnapshot, &me)) {
		if (!_tcsicmp((LPCTSTR)me.szModule, DllFullPath) || !_tcsicmp((LPCTSTR)me.szExePath, DllFullPath))
		{
			bFound = TRUE;
			break;
		}
	}
	if (!bFound) {
		CloseHandle(hSnapshot);
		return FALSE;
	}

	HANDLE ProcessHandle = NULL;

	ProcessHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, ProcessId);

	if (ProcessHandle == NULL)
	{
		printf("[!]OpenProcess error\n");
		return FALSE;
	}

	LPTHREAD_START_ROUTINE FreeLibraryAddress = NULL;
	HMODULE Kernel32Module = GetModuleHandle(L"Kernel32");
	FreeLibraryAddress = (LPTHREAD_START_ROUTINE)GetProcAddress(Kernel32Module, "FreeLibrary");
	pfnNtCreateThreadEx NtCreateThreadEx = (pfnNtCreateThreadEx)GetProcAddress(GetModuleHandle(L"ntdll.dll"), "NtCreateThreadEx");
	if (NtCreateThreadEx == NULL)
	{
		CloseHandle(ProcessHandle);
		printf("[!]NtCreateThreadEx error\n");
		return FALSE;
	}
	HANDLE ThreadHandle = NULL;

	NtCreateThreadEx(&ThreadHandle, 0x1FFFFF, NULL, ProcessHandle, (LPTHREAD_START_ROUTINE)FreeLibraryAddress, me.modBaseAddr, FALSE, NULL, NULL, NULL, NULL);
	if (ThreadHandle == NULL)
	{
		CloseHandle(ProcessHandle);
		printf("[!]ThreadHandle error\n");
		return FALSE;
	}
	if (WaitForSingleObject(ThreadHandle, INFINITE) == WAIT_FAILED)
	{
		printf("[!]WaitForSingleObject error\n");
		return FALSE;
	}
	CloseHandle(ProcessHandle);
	CloseHandle(ThreadHandle);
	return TRUE;
}

//ж��dll
BOOL   CreateRemoteThreadUnloadDll(LPCWSTR   lpwLibFile, DWORD64   dwProcessId)
{
	BOOL   bRet = FALSE;
	HANDLE   hProcess = NULL, hThread = NULL;
	HANDLE   hSnapshot = NULL;

	__try
	{
		hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwProcessId);
		if (hSnapshot == NULL)
			__leave;
		MODULEENTRY32W   me = { sizeof(MODULEENTRY32W) };
		BOOL   bFound = FALSE;
		BOOL   bMoreMods = Module32FirstW(hSnapshot, &me);
		for (; bMoreMods; bMoreMods = Module32NextW(hSnapshot, &me))
		{
			bFound = (lstrcmpiW(me.szModule, lpwLibFile) == 0) ||
				(lstrcmpiW(me.szExePath, lpwLibFile) == 0);
			if (bFound)
				break;
		}

		if (!bFound)
			__leave;

		hProcess = OpenProcess(
			PROCESS_CREATE_THREAD |
			PROCESS_VM_OPERATION,
			FALSE, dwProcessId);

		if (hProcess == NULL)
			__leave;

		PTHREAD_START_ROUTINE   pfnThreadRnt = (PTHREAD_START_ROUTINE)
			GetProcAddress(GetModuleHandle(L"Kernel32"), "FreeLibrary");
		if (pfnThreadRnt == NULL)
			__leave;

		hThread = MyCreateRemoteThread(hProcess, pfnThreadRnt, me.modBaseAddr);
		
		if (hThread == NULL)
			__leave;

		WaitForSingleObject(hThread, INFINITE);
		bRet = TRUE;
	}
	__finally
	{
		if (hSnapshot != NULL)
			CloseHandle(hSnapshot);

		if (hThread != NULL)
			CloseHandle(hThread);

		if (hProcess != NULL)
			CloseHandle(hProcess);
	}

	return   bRet;
}
//--------------------------------------------------------------------- 
//��������Ȩ��
BOOL   EnableDebugPrivilege()
{
	HANDLE   hToken;
	BOOL   fOk = FALSE;
	if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &hToken))
	{
		TOKEN_PRIVILEGES   tp;
		tp.PrivilegeCount = 1;
		if (!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &tp.Privileges[0].Luid));
		tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
		if (!AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL));
		else
			fOk = TRUE;
		CloseHandle(hToken);
	}
	return   fOk;
}



//--------------------------------------------------------------------- 
//����ϵͳ�汾�ж�
BOOL IsVistaOrLater()
{
	OSVERSIONINFO osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osvi);
	if (osvi.dwMajorVersion >= 6)
		return TRUE;
	return FALSE;
}
//--------------------------------------------------------------------- 
//OD���٣����������õ���NtCreateThreadEx,���������ֶ�����
HANDLE MyCreateRemoteThread(HANDLE hProcess, LPTHREAD_START_ROUTINE pThreadProc, LPVOID pRemoteBuf)
{
	HANDLE      hThread = NULL;
	if (IsVistaOrLater())    // Vista, 7, Server2008  ......WIN11
	{		

		pfnNtCreateThreadEx NtCreateThreadEx = (pfnNtCreateThreadEx)GetProcAddress(GetModuleHandle(L"ntdll.dll"), "NtCreateThreadEx");
		

		if (NtCreateThreadEx == NULL)
		{
			printf("MyCreateRemoteThread() : GetProcAddress(\"NtCreateThreadEx\") ����ʧ�ܣ��������: [%d]/n",				GetLastError());
			return FALSE;
		}
		NtCreateThreadEx(
			&hThread,
			0x1FFFFF,
			NULL,
			hProcess,
			pThreadProc,
			pRemoteBuf,
			FALSE,
			NULL,
			NULL,
			NULL,
			NULL);
		
		if (hThread == NULL)
		{
			printf("MyCreateRemoteThread() : NtCreateThreadEx() ����ʧ�ܣ��������: [%d]/n", GetLastError());
			return FALSE;
		}
		
	}
	else                    // 2000, XP, Server2003  
	{
	
		hThread = CreateRemoteThread(hProcess,
			NULL,
			0,
			pThreadProc,
			pRemoteBuf,
			0,
			NULL);
		if (hThread == NULL)
		{

			printf("MyCreateRemoteThread() : CreateRemoteThread() ����ʧ�ܣ��������: [%d]/n", GetLastError());
			return FALSE;
		}
	
	}
	if (WAIT_FAILED == WaitForSingleObject(hThread, INFINITE))

	{
		printf("MyCreateRemoteThread() : WaitForSingleObject() ����ʧ�ܣ��������: [%d]/n", GetLastError());
		return FALSE;
	}
	return hThread;
}
