#pragma once
#define RISKAPIPROXY_EXPORTS 
#include "stdafx.h"

#ifdef RISKAPIPROXY_EXPORTS
#define RISKAPIPROXY_API __declspec(dllexport)
#else
#define RISKAPIPROXY_API __declspec(dllimport)
#endif


extern "C" RISKAPIPROXY_API BOOL   CreateRemoteThreadLoadDll(LPCWSTR   lpwLibFile, DWORD64  dwProcessId);
extern "C" RISKAPIPROXY_API BOOL   CreateRemoteThreadUnloadDll(LPCWSTR   lpwLibFile, DWORD64   dwProcessId);
extern "C" RISKAPIPROXY_API HANDLE MyCreateRemoteThread(HANDLE hProcess, LPTHREAD_START_ROUTINE pThreadProc, LPVOID pRemoteBuf);
extern "C" RISKAPIPROXY_API BOOL CheckIsInject(DWORD dwProcessid);

